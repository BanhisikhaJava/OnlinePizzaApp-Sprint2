import { Component, OnInit } from '@angular/core';
import { SPizzaServicePizza,Pizza } from '../s-pizza.service.pizza';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pizza-employee',
  templateUrl: './add-pizza.component.html',
  styleUrls: ['./add-pizza.component.css']
})
export class AddPizzaComponent implements OnInit {

  user: Pizza = new Pizza(0,"","","",0);

  constructor(private pizzaService: SPizzaServicePizza) { }

  ngOnInit() {
  }
    CreatePizza(): void {
      this.pizzaService.addPizza(this.user).subscribe( data => { alert("Pizza added successfully.");});
      
         
         }

}
