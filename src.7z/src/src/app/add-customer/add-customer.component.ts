import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCustomer, Customer} from '../s-pizza.service.customer'
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  user: Customer = new Customer(0,"",0,"","","","");

  constructor(private employeeService: SPizzaServiceCustomer) { }

  ngOnInit() {
  }
    CreateCustomer(): void {
      this.employeeService.CreateCustomer(this.user).subscribe( data => { alert("Customer created successfully.");});
      
         
         }

}
