import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCaritemComponent } from './add-caritem.component';

describe('AddCaritemComponent', () => {
  let component: AddCaritemComponent;
  let fixture: ComponentFixture<AddCaritemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCaritemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCaritemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
