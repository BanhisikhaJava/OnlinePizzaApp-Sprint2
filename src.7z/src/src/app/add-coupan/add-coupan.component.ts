import { Component, OnInit } from '@angular/core';

import { CoupanServiceService, Coupan } from '../coupan-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-coupan',
  templateUrl: './add-coupan.component.html',
  styleUrls: ['./add-coupan.component.css']
})
export class AddCoupanComponent implements OnInit {

  add: Coupan= new Coupan(0, "", "",0);

  constructor(private coupanService:CoupanServiceService) { }

  ngOnInit(): void {
  }

  CreateCoupan(): void{
    this.coupanService.CreateCoupan(this.add).subscribe(data=> { alert("Coupan Added!!!");});
  }

}
