import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  //templateUrl: './app.component.html',
  //template: ' Name: <input [id]="myId" value="banhisikha">',
  template: 'Name: <input id={{myId}} value="Banhisikha">',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'A4-PropertyBinding';

  myId='capg102';
}
