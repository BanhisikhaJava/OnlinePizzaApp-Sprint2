import { Component, OnInit } from '@angular/core';
import {  Order, OrderserviceService } from '../orderservice.service';
import { Cart } from '../s-pizza.service.cart';
import { Customer } from '../s-pizza.service.customer';
import { Coupan } from '../coupan-service.service';
import { Pizza } from '../s-pizza.service.pizza';
import { CartItem } from '../s-pizza.service.cart';
@Component({
  selector: 'app-book-order',
  templateUrl: './book-order.component.html',
  styleUrls: ['./book-order.component.css']
})
export class BookOrderComponent implements OnInit {

  pizza: Pizza=new Pizza(0,"","","",0);
  customer: Customer =new Customer(0,"",0,"","","",""); 
  cartItem: CartItem = new CartItem(0,this.pizza,"",0,this.customer);
  cart: Cart =new Cart(0,this.customer,0,this.cartItem);
  coupan: Coupan=new Coupan(0,"","",0);
  user: Order = new Order(0,"",new Date(),this.customer,this.coupan,this.cart,0);
  

  constructor(private ordService: OrderserviceService) { }

  ngOnInit() {}
    
  BookOrder(): void {
    this.ordService.bookOrder(this.user).subscribe( data => { 
        alert("Booked Order successfully");
      },error =>{
        alert(error.error.data);
        console.log(error.error.data);  
      }
      );  
       
    }

}

