import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

/*
 * Author : ANURON MULLIK
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Service of Login
*/

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  customer: Customer[] = [];

  constructor(private httpService: HttpClient) { }

   /****************************
	 * Method: AddUser
	 * Description: It is used to register a customer
	 * Created By- Anuron Mullik
   * Created Date -  03-07-2021 
	 ****************************/

  AddUser(customer: Customer):Observable<Customer> {
    console.log(customer);
      return this.httpService.post<Customer>("http://localhost:9999/Admin_Login/Register",customer);
  }

  /****************************
	 * Method: login
	 * Description: It is used for login purpose 
	 * Created By- Anuron Mullik
   * Created Date -  03-07-2021 
	 ****************************/

  login(adminName: string, password: string){
      return this.httpService.post<string>("http://localhost:9999/Admin_Login/Login/"+adminName+"/"+password,{});
  }

}
export class Customer{
  success: any;
  message(message: any) {
    throw new Error('Method not implemented.');
  }

  public adminName: string;
  public adminid: string;
  public mailId: string;
  public password: string;
  constructor( adminName:string,adminid:string,mailId:string,password:string) {
    this.adminName=adminName;
    this.adminid=adminid;
    this.mailId=mailId;
    this.password=password;

  }
}
