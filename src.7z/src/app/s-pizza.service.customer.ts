import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Service of Customer
*/

@Injectable({
  providedIn: 'root'
})
export class SPizzaServiceCustomer {

  customer: Customer[] = [];

  constructor(private httpService: HttpClient) { }

  /****************************
	 * Method: CreateCustomer
	 * Description: It is used to add customer
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  CreateCustomer(customer: Customer): Observable<Customer> {
    console.log(customer);
    return this.httpService.post<Customer>("http://localhost:9999/customer/insert",customer);
  }

  /****************************
	 * Method: deleteCustomer
	 * Description: It is used to delete customer by customerId
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public deleteCustomer(customer: Customer) {
    return this.httpService.delete<Customer>("http://localhost:9999/customer/DeleteCustomer/"+customer.customerId);
  }

  /****************************
	 * Method: updateCustomer
	 * Description: It is used to update information of a customer
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public updateCustomer(customer: Customer) {
    console.log(customer);
    return this.httpService.put<Customer>("http://localhost:9999/customer/edit",customer);
  }

  /****************************
	 * Method: getCustomer
	 * Description: It is used to retrieve customer information
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public getCustomer() {
    return this.httpService.get<Customer[]>("http://localhost:9999/customer/retrieve");
  }

  /****************************
	 * Method: getCustomerById
	 * Description: It is used to get Customer information by customerId
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public getCustomerById(customerId: number) {
    return this.httpService.get<any>("http://localhost:9999/customer/viewonecustomer/"+customerId);
  }
  
}

export class Customer {

  public customerId: number;
  public customerName: string;
  public customerMobile: number;
  public customerEmail: string;
  public customerAddress: string;
  public userName: string;
  public password: string;


  constructor(customerId: number, customerName: string, customerMobile: number, customerEmail: string, customerAddress: string, userName: string, password: string) {
    this.customerId = customerId;
    this.customerName = customerName;
    this.customerMobile = customerMobile;
    this.customerEmail = customerEmail;
    this.customerAddress= customerAddress;
    this.userName=userName;
    this.password=password;

  }
}
