import { Component, OnInit } from '@angular/core';
import { CoupanServiceService, Coupan } from '../coupan-service.service';

@Component({
  selector: 'app-update-coupan',
  templateUrl: './update-coupan.component.html',
  styleUrls: ['./update-coupan.component.css']
})
export class UpdateCoupanComponent implements OnInit {

add: Coupan=new Coupan(0, "", "", 0);

  constructor(private coupanService:CoupanServiceService) { }

  ngOnInit(){
  }

  updateCoupan():void{
    
    this.coupanService.updateCoupan(this.add).subscribe(data=>{});
    console.log("Success");
    alert("Updated");
  }

}
