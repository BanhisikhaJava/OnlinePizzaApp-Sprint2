import { Component, OnInit } from '@angular/core';
import { SPizzaServicePizza ,Pizza} from '../s-pizza.service.pizza';
import { Router } from '@angular/router';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of all pizza list
*/
@Component({
  selector: 'app-list-pizza',
  templateUrl: './list-pizza.component.html',
  styleUrls: ['./list-pizza.component.css']
})
/****************************
 * Class: ListPizzaComponent
 * Description: It is used to find all customer 
 * Created By- Banhisikha Chanda
 * Created Date -  03-07-2021 
 ****************************/
export class ListPizzaComponent implements OnInit {
user: Pizza = new Pizza(0,"","","",0);
  pizzas!: Pizza[];
 
  
  constructor(private pizzaService: SPizzaServicePizza,private router: Router) { }
 /****************************
     * Method: ngOnInit
     * Description: It is used to get all the pizza
     * Created By- Banhisikha Chanda
     * Created Date -  03-07-2021 
     ****************************/
  ngOnInit() {
    this.pizzaService.viewAllPizza().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  handleSuccessfulResponse(response: Pizza[] )
{
    this.pizzas=response;
}
  /****************************
     * Method: deletePizza
     * Description: It is used to delete the customer
     * Created By- Banhisikha Chanda
     * Created Date -  03-07-2021 
     ****************************/
  deletePizza(pizza: Pizza): void {
    this.pizzaService.deletePizza(pizza)
      .subscribe( data => {
        this.pizzas = this.pizzas.filter(u => u !== pizza);});
      
  }

  }
   
  



