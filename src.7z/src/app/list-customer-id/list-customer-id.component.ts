import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Customer, SPizzaServiceCustomer } from '../s-pizza.service.customer';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of Finding customer by id 
*/
@Component({
  selector: 'app-list-customer-id',
  templateUrl: './list-customer-id.component.html',
  styleUrls: ['./list-customer-id.component.css']
})
  /****************************
	 * Class: ListCustomerIdComponent
	 * Description: It is used to find the customer using customer id
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/
export class ListCustomerIdComponent implements OnInit {

  //user: Pizza = new Pizza(0,"","","",0,0,0);
  customer!: Customer;
  customerId!: number;
  constructor(private empService: SPizzaServiceCustomer, private router: Router) { }

  ngOnInit() {

  }
/****************************
	 * Method: getCustomer
	 * Description: It is used to get the customer id from the user and send to the service
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/
  getCustomer(customerId: number) {
    console.log(customerId);
    this.empService.getCustomerById(this.customerId)
      .subscribe(data => { this.customer = data.data }
        , error => {
          alert(error.error.data);
          console.log(error.error.data);
        });


  }



}
