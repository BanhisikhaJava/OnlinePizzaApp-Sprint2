import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddPizzaComponent } from './add-pizza/add-pizza.component';
import { UpdatePizzaComponent } from './update-pizza/update-pizza.component';
import { ListPizzaComponent } from './list-pizza/list-pizza.component';
import { ListPizzaIdComponent } from './list-pizza-id/list-pizza-id.component';
import { FilterPizzaComponent } from './filter-pizza/filter-pizza.component';
import { AddCustomerComponent} from './add-customer/add-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { ListCustomersComponent } from './list-customers/list-customers.component';
import { ListCustomerIdComponent} from './list-customer-id/list-customer-id.component';
import { ListCaritemComponent } from './list-caritem/list-caritem.component';
import { ListCartComponent } from './list-cart/list-cart.component';
import { ListCartitemsIdComponent } from './list-cartitems-id/list-cartitems-id.component';
import { AddCaritemComponent } from './add-caritem/add-caritem.component';
import { CreateCartComponent } from './create-cart/create-cart.component';
import { UpdateCaritemComponent } from './update-caritem/update-caritem.component';
import { ListCartIdComponent } from './list-cart-id/list-cart-id.component';
import { ListCoupanComponent } from './list-coupan/list-coupan.component';
import { AddCoupanComponent } from './add-coupan/add-coupan.component';
import { UpdateCoupanComponent } from './update-coupan/update-coupan.component';
import { ViewOrderbyidComponent } from './view-orderbyid/view-orderbyid.component';
import { BookOrderComponent } from './book-order/book-order.component';
import { ListOrdersComponent } from './list-orders/list-orders.component';
import { LogInComponent } from './log-in/log-in.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './login/login.component';
import { ListPizzaUserComponent } from './list-pizza-user/list-pizza-user.component';
import { ListCoupanUserComponent } from './list-coupan-user/list-coupan-user.component';



const routes: Routes = [
  
{path:'admin/addpizza',component:AddPizzaComponent},
{path:'admin/updatepizza',component:UpdatePizzaComponent},
{path:'admin/listpizza',component:ListPizzaComponent},
{path:'user/listpizzauser',component:ListPizzaUserComponent},
{path:'user/listpizzaid',component:ListPizzaIdComponent},
{path:'admin/listpizzaid',component:ListPizzaIdComponent},
{path:'user/filterpizza',component:FilterPizzaComponent},
{path:'admin/filterpizza',component:FilterPizzaComponent},
{path:'user/addcust',component:AddCustomerComponent},
{path:'user/updatecust',component:UpdateCustomerComponent},
{path:'admin/listcust',component:ListCustomersComponent},
{path:'admin/listcustid',component:ListCustomerIdComponent},
{path:'admin/listcartitem', component:ListCaritemComponent},
{path:'admin/listcarts', component: ListCartComponent},
{path: 'admin/listcartitemsbyid', component: ListCartitemsIdComponent},
{path: 'user/listcartitemsbyid', component: ListCartitemsIdComponent},
{path: 'user/addcartitem', component: AddCaritemComponent},
{path:'user/createcart', component: CreateCartComponent},
{path:'user/updatecartitem', component: UpdateCaritemComponent},
{path:'admin/listcart', component: ListCartIdComponent},
{path:'user/listcart', component: ListCartIdComponent},
{path: 'admin/listcoupan', component: ListCoupanComponent},
{path: 'user/listcoupanuser', component: ListCoupanUserComponent},
{path: 'admin/addcoupan', component:AddCoupanComponent},
{path: 'admin/updatecoupan', component:UpdateCoupanComponent},
{path: 'admin/listallorders', component: ListOrdersComponent},
{path: 'user/bookorders', component:BookOrderComponent},
{path: 'user/vieworderbyid', component: ViewOrderbyidComponent},
{path: 'admin/vieworderbyid', component: ViewOrderbyidComponent},
{path: 'Login', component:LogInComponent},
{path: 'user', component: UserComponent},
{path: 'admin', component: AdminComponent},
{path: 'register', component: LoginComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
