import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from './s-pizza.service.customer';
import { Pizza } from './s-pizza.service.pizza';

/*
 * Author : ANKUSH KUMAR BOSE
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Service of Cart
*/

@Injectable({
  providedIn: 'root'
})
export class SPizzaServiceCart {
  
  customer: Customer[] = [];
  cartitem: CartItem[] = [];
  cart: Cart[] = [];
  response:any;
  
  constructor(private httpService: HttpClient) { }

  // CreateEmployee(employee: Employee):Observable<Employee> {
  //   console.log(employee);
  //     return this.httpService.post<Employee>("http://localhost:9999/cart/addItem/",employee);
  // }

  /****************************
	 * Method: CreateCart
	 * Description: It is used to add customerId
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  CreateCart(customerId:number){
    return this.httpService.post<Cart[]>("http://localhost:9999/cart/createCart/" + customerId,{});
  }

  /****************************
	 * Method: AddItem
	 * Description: It is used to add cartItem
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  async AddItem(cartitem: CartItem){
    // console.log(cartitem);
    // this.response= await this.httpService.post<CartItem>("http://localhost:9999/cart/addItem",cartitem);
    // console.log
    return await this.httpService.post<CartItem>("http://localhost:9999/cart/addItem",cartitem).toPromise();
  }

  /****************************
	 * Method: UpdateQuantity
	 * Description: It is used to update quantity by using customerId and itemId
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  public UpdateQuantity(cartitem:CartItem){
    return this.httpService.put<CartItem>("http://localhost:9999/cart/updateCartQuantity/"+cartitem.customerId+'/'+cartitem.itemId+'/'+cartitem.quantity,{});
  }

  /****************************
	 * Method: DeleteItem
	 * Description: It is used to delete cartItem by using itemId
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  public DeleteItem(cartitem:CartItem){
    return this.httpService.delete<CartItem>("http://localhost:9999/cart/deleteItemFromCart/"+cartitem.customer.customerId+'/'+cartitem.itemId);
  }

  /****************************
	 * Method: ClearCart
	 * Description: It is used to clear customer information by using customerId
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  ClearCart(cart:Cart){
    return this.httpService.delete<Cart[]>("http://localhost:9999/cart/clearCart/" + cart.customer.customerId);
  }

  /****************************
	 * Method: getItems
	 * Description: It is used to view all cart items
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  getItems(){
    return this.httpService.get<CartItem[]>("http://localhost:9999/cart/viewAllCartitems");
  }

  /****************************
	 * Method: getItemsbyId
	 * Description: It is used to view cart items by using customerId
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  getItemsbyId(customerId:number){
    return this.httpService.get<any>("http://localhost:9999/cart/viewAllCartitems/"+customerId);
  }

  /****************************
	 * Method: getCart
	 * Description: It is used to view the cart by using customerId
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  getCart(customerId:number){
    return this.httpService.get<any>("http://localhost:9999/cart/viewCart/"+ customerId);
  }

  /****************************
	 * Method: getCarts
	 * Description: It is used to view the cart items
	 * Created By- Ankush Kumar Bose
   * Created Date -  03-07-2021 
	 ****************************/

  getCarts(){
    return this.httpService.get<Cart[]>("http://localhost:9999/cart/viewCart");
  }
  // public deleteEmployee(employee: Employee) {
  //   return this.httpService.delete<Employee>("http://localhost:9999/cart//delete/"+ employee.empId);
  // }
  // public updateEmployee(employee: Employee) {
  //   console.log(employee);
  //   return this.httpService.put<Employee>("http://localhost:9999/cart/update", employee);
  // }
  // getEmployees(){
  //   return this.httpService.get<Employee[]>("http://localhost:9999/cart/getAll")
  // }
}

// export class Employee{

//   public empId:number;
//   public empName:string;
//   public empSal:number;

//   constructor( empId:number,empName:string,empSal:number) {
//     this.empId=empId;
//     this.empName=empName;
//     this.empSal=empSal

//   }

// }



export class CartItem{
  [x: string]: any;
  public itemId:any;
  public pizzaName:any;
  public pizzaSize:string;
  public quantity:any;
  public customerId:any;

  constructor(itemId:any,pizza:Pizza, pizzaSize:string,quantity:any,customer:Customer){
    this.itemId=itemId;
    this.customerName=customer.customerName;
    this.pizzaName=pizza.pizzaName;
    this.pizzaSize=pizzaSize;
    this.quantity=quantity;
  }
}
export class Cart{
  customer: any;
  ilter(arg0: (u: any) => boolean): Cart {
    throw new Error('Method not implemented.');
  }
  public cartId:number;
  public customerId:any;
  public total:number;
  public itemId:any;
  filter: any;

  constructor(cartId:number,customer:Customer,total:number,cartitem:CartItem){
    this.cartId=cartId;
    this.customerId=customer.customerId;
    this.itemId=cartitem.itemId;
    this.total=total;
  }

}
