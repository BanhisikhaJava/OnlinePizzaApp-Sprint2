import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCart, CartItem } from '../s-pizza.service.cart';
import { Customer } from '../s-pizza.service.customer';
import { Pizza } from '../s-pizza.service.pizza';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-caritem',
  templateUrl: './add-caritem.component.html',
  styleUrls: ['./add-caritem.component.css']
})
export class AddCaritemComponent implements OnInit {

  pizza: Pizza = new Pizza(0, "", "", "", 0);
  customer: Customer = new Customer(0, "", 0, "", "", "", "");
  user: CartItem = new CartItem(0, this.pizza, "", 0, this.customer);
  custId: number | any;

  constructor(private pizzaService: SPizzaServiceCart) { }

  ngOnInit(): void {
  }

  AddItem(): void {
    console.log(this.user)
    this.user.customerId = parseInt(this.user.customerId)
    this.user.itemId = parseInt(this.user.itemId)
    this.user.pizzaId = parseInt(this.user.pizzaId)
    this.user.quantity = parseInt(this.user.quantity)
    console.log(this.user)
    this.pizzaService.AddItem(this.user).then(data => {
      alert("Item added successfully.");
      console.log(data)
    }, error => {
      alert(error.error.data);
      console.log(error.error.data);
    });


  }
}
