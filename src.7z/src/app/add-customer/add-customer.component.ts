import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCustomer, Customer} from '../s-pizza.service.customer'
import { Router } from '@angular/router';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of Add Customer 
*/
@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
  /****************************
	 * Class: AddCustomerComponent
	 * Description: It is used to add customer
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/
export class AddCustomerComponent implements OnInit {

  user: Customer = new Customer(0,"",0,"","","","");

  constructor(private employeeService: SPizzaServiceCustomer) { }

  ngOnInit() {
  }
  /****************************
	 * Method: CreateCustomer
	 * Description: It is used to get the customer details from the user and send to the service
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/
    CreateCustomer(): void {
      this.employeeService.CreateCustomer(this.user).subscribe( data => { alert("Customer created successfully.Your Customer Id: "+data.customerId);});
      
         
         }

}
