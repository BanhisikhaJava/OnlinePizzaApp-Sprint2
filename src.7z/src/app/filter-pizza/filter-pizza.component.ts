import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pizza, SPizzaServicePizza } from '../s-pizza.service.pizza';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of Filter Pizza 
*/
@Component({
  selector: 'app-filter-pizza',
  templateUrl: './filter-pizza.component.html',
  styleUrls: ['./filter-pizza.component.css']
})
  /****************************
	 * Class: FilterPizzaComponent
	 * Description: It is used to filter pizza
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/
export class FilterPizzaComponent implements OnInit {

  
 
  pizzas!: Pizza[];
  pizzaId!: number;
  mincost!: number;
  maxcost!: number;
  constructor(private empService: SPizzaServicePizza,private router: Router) { }

  ngOnInit() {
    
  }
  /****************************
	 * Method: viewPizzaList
	 * Description: It is used to get the max and min cost from the user and send to the service
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  viewPizzaList(mincost:number, maxcost:number){
    console.log(mincost,maxcost);
    this.empService.viewPizzaList(this.mincost,this.maxcost)
        .subscribe(pizzas=>this.pizzas=pizzas);
       

  }
}