import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pizza, SPizzaServicePizza } from '../s-pizza.service.pizza';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of Finding pizza by id 
*/
@Component({
  selector: 'app-list-pizza-id',
  templateUrl: './list-pizza-id.component.html',
  styleUrls: ['./list-pizza-id.component.css']
})
  /****************************
	 * Class: ListPizzaIdComponent
	 * Description: It is used to find the pizza using pizza id
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/
export class ListPizzaIdComponent implements OnInit {
  pizzas!: Pizza;
  pizzaId!: number;
  constructor(private pizzaService: SPizzaServicePizza,private router: Router) { }

  ngOnInit() {
    
  }
/****************************
	 * Method: getPizza
	 * Description: It is used to get the pizza id from the user and send to the service
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/
  getPizza(pizzaId:number){
    console.log(pizzaId);
    this.pizzaService.getPizza(this.pizzaId)
        .subscribe(data=>{this.pizzas=data.data},
          error => {
            alert(error.error.data);
            console.log(error.error.data);}
          );
       

  }



}
