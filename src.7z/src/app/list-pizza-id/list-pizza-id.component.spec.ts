import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListPizzaIdComponent } from './list-pizza-id.component';

describe('ListEmployeeIdComponent', () => {
  let component: ListPizzaIdComponent;
  let fixture: ComponentFixture<ListPizzaIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListPizzaIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListPizzaIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
