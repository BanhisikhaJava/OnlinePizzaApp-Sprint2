import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCoupanComponent } from './list-coupan.component';

describe('ListCoupanComponent', () => {
  let component: ListCoupanComponent;
  let fixture: ComponentFixture<ListCoupanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListCoupanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCoupanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
