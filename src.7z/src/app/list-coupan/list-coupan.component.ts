import { Component, OnInit } from '@angular/core';

import { CoupanServiceService, Coupan } from '../coupan-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-list-coupan',
  templateUrl: './list-coupan.component.html',
  styleUrls: ['./list-coupan.component.css']
})
export class ListCoupanComponent implements OnInit {

    coupans!: Coupan[];

  constructor(private coupanService:CoupanServiceService, private router:Router) { }

  ngOnInit() {

    this.coupanService.getCoupans().subscribe(
      response=>this.handaleSuccessfulResponce(response)
    );

  }

  handaleSuccessfulResponce(response:Coupan[]){
    this.coupans=response;
  }

  deleteCoupan(coupan:Coupan): void{

   this.coupanService.deleteCoupan(coupan).subscribe();
   alert("Deleted!");

  }

}
