import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCart ,CartItem} from '../s-pizza.service.cart';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list-caritem',
  templateUrl: './list-caritem.component.html',
  styleUrls: ['./list-caritem.component.css']
})
export class ListCaritemComponent implements OnInit {

  cartitems: CartItem[]=[];

  cartitem1:CartItem | any;
  
  constructor(private pizzaService: SPizzaServiceCart,private router: Router) { }

  ngOnInit() {
    this.pizzaService.getItems().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  handleSuccessfulResponse(response: CartItem[] )
{
    this.cartitems=response;
}

DeleteItem(cartitem: CartItem): void {
    this.pizzaService.DeleteItem(cartitem)
      .subscribe( data => {
        this.cartitems = this.cartitems.filter(u => u !== cartitem);});
      
  }

}
