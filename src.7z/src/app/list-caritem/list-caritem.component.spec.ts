import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCaritemComponent } from './list-caritem.component';

describe('ListCaritemComponent', () => {
  let component: ListCaritemComponent;
  let fixture: ComponentFixture<ListCaritemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListCaritemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCaritemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
