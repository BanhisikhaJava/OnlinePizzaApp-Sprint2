import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCart, Cart , CartItem} from '../s-pizza.service.cart';
import { Customer } from '../s-pizza.service.customer';
import { Pizza } from '../s-pizza.service.pizza';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-cart',
  templateUrl: './create-cart.component.html',
  styleUrls: ['./create-cart.component.css']
})
export class CreateCartComponent implements OnInit {

  customer: Customer=new Customer(0,"",0,"","","","");
  pizza: Pizza= new Pizza (0,"","","",0);
  cartitem : CartItem=new CartItem(0,this.pizza,"",0,this.customer)
  user: Cart = new Cart(0,this.customer,0,this.cartitem);
  customerId:number|any;

  constructor(private pizzaService: SPizzaServiceCart) { }

  ngOnInit() {
  }
  CreateCart(customerId:number): void {
      this.pizzaService.CreateCart(this.customerId).subscribe( data => { alert("Cart created successfully.");
    }, error => {
      alert(error.error.data);
      console.log(error.error.data);}
      );
         }

}
