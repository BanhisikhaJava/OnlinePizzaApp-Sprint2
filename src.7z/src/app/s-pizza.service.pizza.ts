import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Service of Pizza 
*/

@Injectable({
  providedIn: 'root'
})
export class SPizzaServicePizza {
  
  pizza: Pizza[] = [];
  
  constructor(private httpService: HttpClient) { }

    /****************************
	 * Method: addPizza
	 * Description: It is used to add pizza
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public addPizza(pizza: Pizza):Observable<Pizza> {
    console.log(pizza);
      return this.httpService.post<Pizza>("http://localhost:9999/pizza/add",pizza);
  }

  /****************************
	 * Method: deletePizza
	 * Description: It is used to delete pizza by using pizzaId
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public deletePizza(pizza: Pizza) {
    return this.httpService.delete<Pizza>("http://localhost:9999/pizza/delete/"+ pizza.pizzaId);
  }

  /****************************
	 * Method: UpdatePizza
	 * Description: It is used to update pizza
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public UpdatePizza(pizza: Pizza) {
    console.log(pizza);
    return this.httpService.put<Pizza>("http://localhost:9999/pizza/UpdatePizza", pizza);
  }

  /****************************
	 * Method: viewAllPizza
	 * Description: It is used to view all pizza items
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public viewAllPizza(){
    return this.httpService.get<Pizza[]>("http://localhost:9999/pizza/viewAllPizza");
  }

  /****************************
	 * Method: getPizza
	 * Description: It is used to view pizza by pizzaId
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public getPizza(pizzaId:number)
  {
    return this.httpService.get<any>("http://localhost:9999/pizza/viewpizza/"+ pizzaId);
  }

  /****************************
	 * Method: viewPizzaList
	 * Description: It is used to view the minimum and maximum cost of pizza
	 * Created By- Banhisikha Chanda
   * Created Date -  03-07-2021 
	 ****************************/

  public viewPizzaList(mincost:number, maxcost:number)
  {
    return this.httpService.get<Pizza[]>("http://localhost:9999/pizza/viewPizzaList/"+mincost+"/"+maxcost);
  }
}

export class Pizza{

  public pizzaId:number;
  public pizzaName:string;
  public pizzaType:string;
  public pizzaDescription:string;
  public pizzaCost:number;


  constructor(pizzaId:number,pizzaName:string,pizzaType:string,pizzaDescription:string,pizzaCost:number) {
    this.pizzaId=pizzaId;
    this.pizzaName=pizzaName;
    this.pizzaType=pizzaType;
    this.pizzaDescription=pizzaDescription;
    this.pizzaCost=pizzaCost;
    
  }
}
