import { Component, OnInit } from '@angular/core';
import { Customer, ServiceService } from '../service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: Customer = new Customer("","","","");
  constructor(private customerService:ServiceService) { }

  ngOnInit()  {
  }
    CreateCustomer():void{
      this.customerService.AddUser(this.user).subscribe( data => { alert("Customer registered successfully.");});
    }

}
