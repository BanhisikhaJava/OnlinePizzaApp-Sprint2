import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {  Order, OrderserviceService } from '../orderservice.service';
import { Cart, CartItem } from '../s-pizza.service.cart';
import { Customer } from '../s-pizza.service.customer';
import { Coupan } from '../coupan-service.service';
import { Pizza } from '../s-pizza.service.pizza';
@Component({
  selector: 'app-list-orders',
  templateUrl: './list-orders.component.html',
  styleUrls: ['./list-orders.component.css']
})
export class ListOrdersComponent implements OnInit {

  pizza: Pizza=new Pizza(0,"","","",0);
  customer: Customer =new Customer(0,"",0,"","","",""); 
  cartItem: CartItem = new CartItem(0,this.pizza,"",0,this.customer);
  cart: Cart =new Cart(0,this.customer,0,this.cartItem);
  coupan: Coupan=new Coupan(0,"","",0);
  user: Order = new Order(0,"",new Date(),this.customer,this.coupan,this.cart,0);
  orders!: Order[];
  customers!:Customer[]; 
    
    constructor(private ordService: OrderserviceService,private router:Router) { }
  
    ngOnInit() {
      this.ordService.viewAllOrder().subscribe(
        response =>this.handleSuccessfulResponse(response),
       );
    }
    handleSuccessfulResponse(response: Order[] )
{
    this.orders=response;
}
         
    deleteOrder(order: Order): void {
    this.ordService.deleteOrder(order)
  .subscribe( data => {
    this.orders = this.orders.filter(u => u !== order);});
   
              
          }

}
