import { Component, OnInit } from '@angular/core';
import { SPizzaServicePizza, Pizza } from '../s-pizza.service.pizza';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of Update Pizza 
*/
@Component({
  selector: 'app-update-pizza',
  templateUrl: './update-pizza.component.html',
  styleUrls: ['./update-pizza.component.css']
})
/****************************
 * Class: UpdatePizzaComponent
 * Description: It is used to add pizza
 * Created By- Banhisikha Chanda
 * Created Date -  03-07-2021 
 ****************************/
export class UpdatePizzaComponent implements OnInit {
  user: Pizza = new Pizza(0, "", "", "", 0);
  constructor(private empService: SPizzaServicePizza) { }
  ngOnInit() {
  }
  /****************************
* Method: updatePizza
* Description: It is used to get the pizza details from the admin and send to the service
* Created By- Banhisikha Chanda
* Created Date -  03-07-2021 
****************************/
  updatePizza(): void {
    console.log(this.user.pizzaId);
    this.empService.UpdatePizza(this.user)
      .subscribe(data => {
        alert("Pizza updated successfully.");
      });

  };
}
