import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListPizzaUserComponent } from './list-pizza-user.component';

describe('ListPizzaUserComponent', () => {
  let component: ListPizzaUserComponent;
  let fixture: ComponentFixture<ListPizzaUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListPizzaUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListPizzaUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
