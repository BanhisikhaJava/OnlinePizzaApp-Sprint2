import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pizza, SPizzaServicePizza } from '../s-pizza.service.pizza';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of all pizza list
*/
@Component({
  selector: 'app-list-pizza-user',
  templateUrl: './list-pizza-user.component.html',
  styleUrls: ['./list-pizza-user.component.css']
})
/****************************
 * Class: ListPizzaUserComponent
 * Description: It is used to find all customer 
 * Created By- Banhisikha Chanda
 * Created Date -  03-07-2021 
 ****************************/
export class ListPizzaUserComponent implements OnInit {

  user: Pizza = new Pizza(0, "", "", "", 0);
  pizzas!: Pizza[];


  constructor(private empService: SPizzaServicePizza, private router: Router) { }
  /****************************
      * Method: ngOnInit
      * Description: It is used to get all the pizza
      * Created By- Banhisikha Chanda
      * Created Date -  03-07-2021 
      ****************************/
  ngOnInit() {
    this.empService.viewAllPizza().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response: Pizza[]) {
    this.pizzas = response;
  }


}
