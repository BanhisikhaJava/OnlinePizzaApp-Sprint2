import { JsonpClientBackend } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { Customer, ServiceService } from '../service.service';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  userName!:string;
  password!:string;
  user!: Customer;
  myForm!:FormGroup;
  
  constructor(private fb: FormBuilder,private loginService:ServiceService,private router:Router) {
    this.createForm();
   }

  ngOnInit(): void {
  }
  createForm() {
    this.myForm = this.fb.group({
       userName: ['', Validators.required ],
       password: ['',Validators.required] 
    });
  }
  goLogin(userName:string,password:string){
    this.loginService.login(this.userName,this.password).subscribe(result => { 
      if(this.userName=="admin" && this.password=="123")
      {
      this.router.navigate(['admin']);
      }
     
     else
     {if(result== null){
      alert("Not Successsful");
      }else{
      this.router.navigate(['user']);
      }

     }
     

      });
   
}

}