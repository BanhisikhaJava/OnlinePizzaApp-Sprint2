import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCartitemsIdComponent } from './list-cartitems-id.component';

describe('ListCartitemsIdComponent', () => {
  let component: ListCartitemsIdComponent;
  let fixture: ComponentFixture<ListCartitemsIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListCartitemsIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCartitemsIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
