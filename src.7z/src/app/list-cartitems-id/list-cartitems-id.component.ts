import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartItem, SPizzaServiceCart } from '../s-pizza.service.cart';


@Component({
  selector: 'app-list-cartitems-id',
  templateUrl: './list-cartitems-id.component.html',
  styleUrls: ['./list-cartitems-id.component.css']
})
export class ListCartitemsIdComponent implements OnInit {

  cartitems!:CartItem[];
  customerId!:number;

  constructor(private pizzaService: SPizzaServiceCart,private router: Router) { }

  ngOnInit(): void {
  }

  getItemsbyId(customerId:number){
    console.log(customerId);
    this.pizzaService.getItemsbyId(this.customerId)
        .subscribe(data=>{
          this.cartitems = data.data
        }
          , error => {
            alert(error.error.data);
            console.log(error.error.data);}
          
          
          );
       

  }
  DeleteItem(cartitem: CartItem): void {
    this.pizzaService.DeleteItem(cartitem)
      .subscribe( data => {
        this.cartitems = this.cartitems.filter(u => u !== cartitem);});
      
  }

}
