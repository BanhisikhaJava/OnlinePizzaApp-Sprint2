import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './s-pizza.service.customer';
import { Cart } from './s-pizza.service.cart';
import { Coupan } from './coupan-service.service';
import { Pizza } from './s-pizza.service.pizza';


/*
 * Author : PUSHPAN BHAUMIK
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Service of Order
*/

@Injectable({
  providedIn: 'root'
})
export class OrderserviceService {

  
    orders: Order[] = [];
    
    constructor(private httpService: HttpClient) { }
  
    /****************************
	 * Method: bookOrder
	 * Description: It is used to add cartId, customerId and coupanId
	 * Created By- Pushpan Bhaumik
   * Created Date -  03-07-2021 
	 ****************************/

    bookOrder(orders: Order):Observable<Order> {
      console.log(orders);
        return this.httpService.post<Order>("http://localhost:9999/orders/insertOrder/"+ orders.cartId + "/" + orders.customerId+ "/"+ orders.coupanId,{});
    }
    
    /****************************
	 * Method: deleteOrder
	 * Description: It is used to delete orderId
	 * Created By- Pushpan Bhaumik
   * Created Date -  03-07-2021 
	 ****************************/

    public deleteOrder(orders: Order) {
      return this.httpService.delete<Order[]>("http://localhost:9999/orders/DeleteOrder/"+orders.orderId);
    }

     /****************************
	 * Method: viewAllOrder
	 * Description: It is used to view all orders
	 * Created By- Pushpan Bhaumik
   * Created Date -  03-07-2021 
	 ****************************/
    
    public viewAllOrder(){
  
      return this.httpService.get<Order[]>("http://localhost:9999/orders/viewAllOrder");
    }

     /****************************
	 * Method: viewOrder
	 * Description: It is used to view order by customerId
	 * Created By- Pushpan Bhaumik
   * Created Date -  03-07-2021 
	 ****************************/

    public viewOrder(customerId:number)
    {
      return this.httpService.get<any>("http://localhost:9999/orders/viewOrderByOrderandCustomerId/"+ customerId );
    }
  }
  
  
  
  
  
  export class Order{
  
    public customer: any;
    public cart:any;
    public coupan:any;
    filter(arg0: (u: any) => boolean): Order {
      throw new Error('Method not implemented.');
    }
  
    public orderId:any ;
    public orderStatus:string;
    public orderDate: Date;
    public customerId: number ;
    public coupanCode: any;
    public coupanId: any;
    public cartId: any;
    public finalPrice: number;
  
    constructor( orderId:number,orderStatus:string , orderDate:Date,customer:Customer,coupan: Coupan,cart: Cart,finalPrice: number) {
     this.orderId=orderId;
     this.orderStatus=orderStatus;
     this.orderDate=orderDate;
     this.customerId=customer.customerId;
     this.coupanId=coupan.coupanId;
     this.coupanCode=coupan.coupanCode;
     this.cartId=cart.cartId;
     this.finalPrice=finalPrice;
  
    }
  }
  
  
  
  
  