import { Injectable } from '@angular/core';

import { Observable, observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

/*
 * Author : ABHISHEK SHAW
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Service of Coupan
*/

@Injectable({
  providedIn: 'root'
})
export class CoupanServiceService {
  
  coupan: Coupan[]=[];

  constructor(private httpService: HttpClient) { }

  /****************************
	 * Method: CreateCoupan
	 * Description: It is used to add Coupan into Coupan table
	 * Created By- Abhishek Shaw
   * Created Date -  03-07-2021 
	 ****************************/


  CreateCoupan(coupan:Coupan): Observable<Coupan>{
    console.log(coupan);
    return this.httpService.post<Coupan>("http://localhost:9999/coupan/add", coupan);
  }

  /****************************
	 * Method: deleteCoupan
	 * Description: It is used to delete Coupan into Coupan table
	 * Created By- Abhishek Shaw
   * Created Date -  03-07-2021 
	 ****************************/

  deleteCoupan(coupan: Coupan){
    console.log(coupan);
    return this.httpService.delete<Coupan>("http://localhost:9999/coupan/delete/"+coupan.coupanId);
  }

   /****************************
	 * Method: updateCoupan
	 * Description: It is used to edit Coupan into Coupan table
	 * Created By- Abhishek Shaw
   * Created Date -  03-07-2021 
	 ****************************/

  updateCoupan(coupan: Coupan){
    console.log(coupan);
    return this.httpService.put<Coupan>("http://localhost:9999/coupan/editCoupan", coupan);
  }

   /****************************
	 * Method: getCoupans
	 * Description: It is used to view all the Coupans from Coupan table
	 * Created By- Abhishek Shaw
   * Created Date -  03-07-2021 
	 ****************************/

  getCoupans(){
    
    return this.httpService.get<Coupan[]>("http://localhost:9999/coupan/viewAllCoupan");
  }

}

export class Coupan{

public coupanId: number;
public coupanCode: string;
public coupanDescription: string;
public coupanDiscount: number;

constructor( coupanId: number, coupanCode: string, coupanDescription: string, coupanDiscount: number){
  this.coupanId=coupanId;
  this.coupanCode=coupanCode;
  this.coupanDescription=coupanDescription;
  this.coupanDiscount=coupanDiscount;
}
}