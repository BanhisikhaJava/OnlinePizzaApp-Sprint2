import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCart,CartItem } from '../s-pizza.service.cart';
import { Customer } from '../s-pizza.service.customer';
import { Pizza } from '../s-pizza.service.pizza';
@Component({
  selector: 'app-update-caritem',
  templateUrl: './update-caritem.component.html',
  styleUrls: ['./update-caritem.component.css']
})
export class UpdateCaritemComponent implements OnInit {

  pizza: Pizza= new Pizza (0,"","","",0);
  customer: Customer=new Customer(0,"",0,"","","","");
  user: CartItem = new CartItem(0,this.pizza,"",0,this.customer);
  constructor(private pizzaService: SPizzaServiceCart) { }

  ngOnInit(): void {
  }

  UpdateQuantity(): void {
    // console.log(this.user.empId);
    this.pizzaService.UpdateQuantity(this.user)
        .subscribe( data => {
          alert("Quantity updated.");
          console.log(data);
      }, error => {
        alert(error.error.data);
        console.log(error.error.data);
        
      });

  };
}
