import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCaritemComponent } from './update-caritem.component';

describe('UpdateCaritemComponent', () => {
  let component: UpdateCaritemComponent;
  let fixture: ComponentFixture<UpdateCaritemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCaritemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateCaritemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
