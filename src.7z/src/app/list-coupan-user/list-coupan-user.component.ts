import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Coupan, CoupanServiceService } from '../coupan-service.service';

@Component({
  selector: 'app-list-coupan-user',
  templateUrl: './list-coupan-user.component.html',
  styleUrls: ['./list-coupan-user.component.css']
})
export class ListCoupanUserComponent implements OnInit {

  coupans!: Coupan[];

  constructor(private coupanService:CoupanServiceService, private router:Router) { }

  ngOnInit() {

    this.coupanService.getCoupans().subscribe(
      response=>this.handaleSuccessfulResponce(response)
    );

  }

  handaleSuccessfulResponce(response:Coupan[]){
    this.coupans=response;
  }
}