import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCoupanUserComponent } from './list-coupan-user.component';

describe('ListCoupanUserComponent', () => {
  let component: ListCoupanUserComponent;
  let fixture: ComponentFixture<ListCoupanUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListCoupanUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCoupanUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
