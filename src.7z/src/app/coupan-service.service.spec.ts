import { TestBed } from '@angular/core/testing';

import { CoupanServiceService } from './coupan-service.service';

describe('CoupanServiceService', () => {
  let service: CoupanServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CoupanServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
