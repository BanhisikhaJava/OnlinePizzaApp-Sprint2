import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCustomer, Customer } from '../s-pizza.service.customer';
import { Router } from '@angular/router';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of all customers list
*/
@Component({
  selector: 'app-list-customers',
  templateUrl: './list-customers.component.html',
  styleUrls: ['./list-customers.component.css']
})
/****************************
 * Class: ListCustomersComponent
 * Description: It is used to find all customer 
 * Created By- Banhisikha Chanda
 * Created Date -  03-07-2021 
 ****************************/
export class ListCustomersComponent implements OnInit {

  customers!: Customer[];

  constructor(private custService: SPizzaServiceCustomer, private router: Router) { }
  /****************************
     * Method: ngOnInit
     * Description: It is used to get all the customer
     * Created By- Banhisikha Chanda
     * Created Date -  03-07-2021 
     ****************************/
  ngOnInit() {
    this.custService.getCustomer().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response: Customer[]) {
    this.customers = response;
  }
  /****************************
     * Method: deleteCustomer
     * Description: It is used to delete the customer
     * Created By- Banhisikha Chanda
     * Created Date -  03-07-2021 
     ****************************/
  deleteCustomer(customer: Customer): void {
    this.custService.deleteCustomer(customer)
      .subscribe(data => {
        this.customers = this.customers.filter(u => u !== customer);
      });

  }


}
