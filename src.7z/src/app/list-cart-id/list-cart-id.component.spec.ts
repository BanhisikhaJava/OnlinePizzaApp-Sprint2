import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCartIdComponent } from './list-cart-id.component';

describe('ListCartIdComponent', () => {
  let component: ListCartIdComponent;
  let fixture: ComponentFixture<ListCartIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListCartIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCartIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
