import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCart ,Cart} from '../s-pizza.service.cart';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-cart-id',
  templateUrl: './list-cart-id.component.html',
  styleUrls: ['./list-cart-id.component.css']
})
export class ListCartIdComponent implements OnInit {

  carts!: Cart;
  customerId!: number;

  constructor(private pizzaService: SPizzaServiceCart,private router: Router) { }

  ngOnInit(): void {
  }

  getCart(customerId:number){
    console.log(customerId);
    this.pizzaService.getCart(this.customerId)
        .subscribe(data=>{this.carts=data.data}
          , error => {
            alert(error.error.data);
            console.log(error.error.data);}
          
          
          
          );
       
  
  }

  ClearCart(cart: Cart): void {
    this.pizzaService.ClearCart(cart)
  .subscribe( data => {
    this.carts = this.carts.filter((u:any) => u !== cart);});
              
          }
}
