import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order, OrderserviceService } from '../orderservice.service';
import { Customer } from '../s-pizza.service.customer';
import { Cart } from '../s-pizza.service.cart';
import { Coupan } from '../coupan-service.service';
import { CartItem } from '../s-pizza.service.cart';
import { Pizza } from '../s-pizza.service.pizza';
@Component({
  selector: 'app-view-orderbyid',
  templateUrl: './view-orderbyid.component.html',
  styleUrls: ['./view-orderbyid.component.css']
})
export class ViewOrderbyidComponent implements OnInit {
  pizza: Pizza=new Pizza(0,"","","",0);
  customer: Customer =new Customer(0,"",0,"","","",""); 
  cartItem: CartItem = new CartItem(0,this.pizza,"",0,this.customer);
  cart: Cart =new Cart(0,this.customer,0,this.cartItem);
  coupan: Coupan=new Coupan(0,"","",0);
  user: Order = new Order(0,"",new Date(),this.customer,this.coupan,this.cart,0);
  
  orders!: Order[];
  orderId! : number;
  customerId!: number;
  constructor(private ordService: OrderserviceService,private router: Router) { }
  
  ngOnInit() {}
  
  viewOrder(customerId:number){
 
  this.ordService.viewOrder(this.customerId)
  .subscribe(data=>{this.orders=data.data},
    error => {
      alert(error.error.data);
      console.log(error.error.data);}
    );
         
   }

  deleteOrder(order: Order): void {
  this.ordService.deleteOrder(order)
  .subscribe( data => {
  this.orders = this.orders.filter(u => u !== order);});
                
    }
}
