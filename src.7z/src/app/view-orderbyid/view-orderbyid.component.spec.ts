import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewOrderbyidComponent } from './view-orderbyid.component';

describe('ViewOrderbyidComponent', () => {
  let component: ViewOrderbyidComponent;
  let fixture: ComponentFixture<ViewOrderbyidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewOrderbyidComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewOrderbyidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
