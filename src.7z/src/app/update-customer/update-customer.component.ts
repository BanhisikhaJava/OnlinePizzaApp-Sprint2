import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCustomer, Customer } from '../s-pizza.service.customer';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of Update Customer 
*/
@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
/****************************
  * Class: UpdateCustomerComponent
  * Description: It is used to add customer
  * Created By- Banhisikha Chanda
  * Created Date -  03-07-2021 
  ****************************/
export class UpdateCustomerComponent implements OnInit {
  user: Customer = new Customer(0, "", 0, "", "", "", "");
  constructor(private empService: SPizzaServiceCustomer) { }
  ngOnInit() {
  }
  /****************************
 * Method: updateCustomer
 * Description: It is used to get the customer details from the user and send to the service
 * Created By- Banhisikha Chanda
 * Created Date -  03-07-2021 
 ****************************/
  updateCustomer(): void {
    console.log(this.user.customerId);
    this.empService.updateCustomer(this.user)
      .subscribe(data => {
        alert("Customer updated successfully.");
      }, error => {
        alert(error.error.data);
        console.log(error.error.data);
      });

  };
}
