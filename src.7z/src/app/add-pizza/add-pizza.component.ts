import { Component, OnInit } from '@angular/core';
import { SPizzaServicePizza, Pizza } from '../s-pizza.service.pizza';
/*
 * Author : BANHISIKHA CHANDA
 * Version : 1.0
 * Date : 03-07-2021
 * Description : This is Component of Add Pizza 
*/

@Component({
  selector: 'app-pizza-employee',
  templateUrl: './add-pizza.component.html',
  styleUrls: ['./add-pizza.component.css']
})
/****************************
 * Class: AddPizzaComponent
 * Description: It is used to add pizza
 * Created By- Banhisikha Chanda
 * Created Date -  03-07-2021 
 ****************************/
export class AddPizzaComponent implements OnInit {

  user: Pizza = new Pizza(0, "", "", "", 0);

  constructor(private pizzaService: SPizzaServicePizza) { }

  ngOnInit() {
  }
  /****************************
 * Method: CreatePizza
 * Description: It is used to get the pizza details from the admin and send to the service
 * Created By- Banhisikha Chanda
 * Created Date -  03-07-2021 
 ****************************/
  CreatePizza(): void {
    this.pizzaService.addPizza(this.user).subscribe(data => { alert("Pizza added successfully."); });


  }

}
