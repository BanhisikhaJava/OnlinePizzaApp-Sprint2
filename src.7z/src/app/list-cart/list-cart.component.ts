import { Component, OnInit } from '@angular/core';
import { SPizzaServiceCart ,Cart} from '../s-pizza.service.cart';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-cart',
  templateUrl: './list-cart.component.html',
  styleUrls: ['./list-cart.component.css']
})
export class ListCartComponent implements OnInit {

  carts: Cart[]=[];
  customerId!: number;
  
  constructor(private pizzaService: SPizzaServiceCart,private router: Router) { }

  ngOnInit() {
    this.pizzaService.getCarts().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  handleSuccessfulResponse(response: Cart[] )
{
    this.carts=response;
}
  
  

  ClearCart(cart: Cart): void {
      this.pizzaService.ClearCart(cart)
        .subscribe( data => {
          this.carts = this.carts.filter(u => u !== cart);});
        

    }

}
