import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddPizzaComponent } from './add-pizza/add-pizza.component';
import { UpdatePizzaComponent } from './update-pizza/update-pizza.component';
import { ListPizzaComponent } from './list-pizza/list-pizza.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { SPizzaServicePizza } from './s-pizza.service.pizza';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { ListPizzaIdComponent } from './list-pizza-id/list-pizza-id.component';
import { FilterPizzaComponent } from './filter-pizza/filter-pizza.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { ListCustomersComponent } from './list-customers/list-customers.component';
import { ListCustomerIdComponent } from './list-customer-id/list-customer-id.component';
import { SPizzaServiceCart } from './s-pizza.service.cart';
import { SPizzaServiceCustomer } from './s-pizza.service.customer';
import { AddCaritemComponent } from './add-caritem/add-caritem.component';
import { UpdateCaritemComponent } from './update-caritem/update-caritem.component';
import { CreateCartComponent } from './create-cart/create-cart.component';
import { ListCartitemsIdComponent } from './list-cartitems-id/list-cartitems-id.component';
import { ListCartComponent } from './list-cart/list-cart.component';
import { ListCartIdComponent } from './list-cart-id/list-cart-id.component';
import { ListCaritemComponent } from './list-caritem/list-caritem.component';
import { AddCoupanComponent } from './add-coupan/add-coupan.component';
import { ListCoupanComponent } from './list-coupan/list-coupan.component';
import { UpdateCoupanComponent } from './update-coupan/update-coupan.component';
import { ViewOrderbyidComponent } from './view-orderbyid/view-orderbyid.component';
import { BookOrderComponent } from './book-order/book-order.component';
import { ListOrdersComponent } from './list-orders/list-orders.component';
import { UserComponent } from './user/user.component';
import { LogInComponent } from './log-in/log-in.component';
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './login/login.component';
import { ListPizzaUserComponent } from './list-pizza-user/list-pizza-user.component';
import { ListCoupanUserComponent } from './list-coupan-user/list-coupan-user.component';

@NgModule({
  declarations: [
    AppComponent,
    AddPizzaComponent,
    UpdatePizzaComponent,
    ListPizzaComponent,
    ListPizzaIdComponent,
    FilterPizzaComponent,
    AddCustomerComponent,
    UpdateCustomerComponent,
    ListCustomersComponent,
    ListCustomerIdComponent,
    AddCaritemComponent,
    UpdateCaritemComponent,
    CreateCartComponent,
    ListCartitemsIdComponent,
    ListCartComponent,
    ListCartIdComponent,
    ListCaritemComponent,
    AddCoupanComponent,
    ListCoupanComponent,
    UpdateCoupanComponent,
    ViewOrderbyidComponent,
    BookOrderComponent,
    ListOrdersComponent,
    UserComponent,
    LogInComponent,
    AdminComponent,
    LoginComponent,
    ListPizzaUserComponent,
    ListCoupanUserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [HttpClient,SPizzaServicePizza],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
