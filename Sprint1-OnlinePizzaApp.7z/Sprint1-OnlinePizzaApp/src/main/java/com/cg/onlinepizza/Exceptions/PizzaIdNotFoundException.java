package com.cg.onlinepizza.Exceptions;

public class PizzaIdNotFoundException extends Exception{

	public PizzaIdNotFoundException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}


}
