package com.cg.onlinepizza.Exceptions;

public class CartIdNotFoundException extends Exception {

	public CartIdNotFoundException(String arg0) {
		super(arg0);
		
	}

	
}
