package com.cg.onlinepizza.Exceptions;

public class CoupanIdNotFoundException extends Exception{
	public CoupanIdNotFoundException(String string)
	{
		super(string);
		
	}

}
