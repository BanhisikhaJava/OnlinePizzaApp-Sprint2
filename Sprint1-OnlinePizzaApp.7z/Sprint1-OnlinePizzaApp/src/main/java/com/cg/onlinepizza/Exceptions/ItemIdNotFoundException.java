package com.cg.onlinepizza.Exceptions;

public class ItemIdNotFoundException extends Exception{

	public ItemIdNotFoundException(String message) {
		super(message);
		
	}

}
