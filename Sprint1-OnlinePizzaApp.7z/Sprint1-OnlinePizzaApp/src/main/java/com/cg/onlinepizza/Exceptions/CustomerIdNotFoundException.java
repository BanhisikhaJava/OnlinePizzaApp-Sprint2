package com.cg.onlinepizza.Exceptions;

public class CustomerIdNotFoundException extends Exception {
	

	public CustomerIdNotFoundException(String message) {
		super(message);
	}

}
