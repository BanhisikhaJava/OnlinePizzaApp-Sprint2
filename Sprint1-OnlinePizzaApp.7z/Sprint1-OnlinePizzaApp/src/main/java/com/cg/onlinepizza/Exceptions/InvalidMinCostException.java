package com.cg.onlinepizza.Exceptions;

public class InvalidMinCostException extends Exception{
	public InvalidMinCostException(String string)
	{
		super(string);
		
	}

}
