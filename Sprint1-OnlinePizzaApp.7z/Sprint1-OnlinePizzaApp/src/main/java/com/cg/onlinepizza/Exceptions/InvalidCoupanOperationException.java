package com.cg.onlinepizza.Exceptions;

public class InvalidCoupanOperationException extends Exception{
	public InvalidCoupanOperationException(String string)
	{
		super(string);
	}

}
