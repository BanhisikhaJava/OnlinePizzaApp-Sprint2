package com.cg.onlinepizza.Exceptions;

public class NullArgumentException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public NullArgumentException() {
		super();
		
	}

}
