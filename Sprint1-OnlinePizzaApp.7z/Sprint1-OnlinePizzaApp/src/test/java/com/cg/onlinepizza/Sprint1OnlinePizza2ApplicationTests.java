package com.cg.onlinepizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint1OnlinePizza2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
