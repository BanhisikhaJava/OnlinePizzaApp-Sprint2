{
    "adminid": "123",
    "adminName": "Anuron",
    "mailId": "abc@gmail.com",
    "password": "123"
}

Register:
URL- http://localhost:9091/Admin_Login/Register

Login:
URL- http://localhost:9091/Admin_Login/Login?userName=Anuron&password=123

Logout:
URL- http://localhost:9091/Admin_Login/Logout

